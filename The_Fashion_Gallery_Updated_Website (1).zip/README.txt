THE FASHION GALLERY - UPDATED WEBSITE FILES

1) Extract this ZIP on your Windows laptop (right-click > Extract All).
2) Open your GitHub repository:
   https://github.com/ahirdinesh957-ui/THE-FASHION-GALLERY
3) Click Add file > Upload files.
4) Upload index.html and the images folder (keep the three image filenames inside images).
5) Click Commit changes.
6) Wait a few minutes and refresh:
   https://ahirdinesh957-ui.github.io/THE-FASHION-GALLERY/

Note: jeans/trousers photos are still sample/online images. Replace them with your actual photos when ready. Prices remain a range until you confirm exact prices per item.
